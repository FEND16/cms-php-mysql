<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$options = [ 
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES   => false
];


$pdo = new PDO(
  "mysql:host=localhost:8889;dbname=products;charset=utf8",
  "root",
  "root", $options);

$speed = 700;

//Prepare SQL query
$st = $pdo->prepare("
  SELECT * FROM pc WHERE speed > :speed");

//Execute statement, fetch data
$st->execute([
  ":speed" => $speed
]);

//Fetch data for real: associative array
// $data = $st->fetchAll();

// echo "<ul>";
// foreach ($data as $row){
//   if( $row['price'] < 1299){
//     echo "<li>" . $row["model"] . " - " .$row["price"] . "</li>";
//   }
// }
// echo "</ul>";

highlight_string("<?php\n\$data =\n" . var_export($_GET, true) . ";\n?>");


// $statement = $pdo->prepare("
//   INSERT INTO pc (model, price)
//   VALUES (:model, :price)");

// //Execute statement, fetch data
// $statement->execute([
//   ":model" => $model,
//   ":price" => "10000000"
// ]);








