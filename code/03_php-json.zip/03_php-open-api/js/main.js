function printHtml(data){
  html = "";
  for (let quote of data){
    html += `<div class="col-md-12 d-flex justify-content-center p-5">
              <div class="card">
                <div class="card-header">
                  Quote of the day
                </div>
                <div class="card-block">
                  <blockquote class="card-blockquote">
                    <p>${quote.content}</p>
                <footer><cite title="Source Title">${quote.title}</cite></footer>
              </blockquote>
            </div>
        </div>
      </div>`;
  }
  document.getElementById('content').innerHTML = html;
}