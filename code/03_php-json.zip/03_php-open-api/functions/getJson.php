<?php
 
function get_file(){ 
  $data = file_get_contents("http://quotesondesign.com/wp-json/posts?filter[orderby]=rand&filter[posts_per_page]=20/");
    return $data;
}

get_file();