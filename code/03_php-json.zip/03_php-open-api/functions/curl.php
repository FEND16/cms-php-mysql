<?php

function curl_it(){
  $url = 'http://quotesondesign.com/wp-json/posts?filter[orderby]=rand&filter[posts_per_page]=20/';

  //starta request
  $ch = curl_init();

  curl_setopt($ch, CURLOPT_URL,$url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  // Här är vår data som returneras
  $data = curl_exec($ch);
  //avsluta request
  curl_close($ch);

  return json_decode($data, true);
}


$data = curl_it();
