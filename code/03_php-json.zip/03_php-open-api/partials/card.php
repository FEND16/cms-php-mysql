<div class="col-md-12 d-flex justify-content-center p-5">
  <div class="card">
    <div class="card-header">
      Quote of the day
    </div>
    <div class="card-block">
      <blockquote class="card-blockquote">
        <p>

          <?= $card['content']; ?>
              
        </p>
        <footer>
          <cite title="Source Title">

            <?= $card['title'] ?>

          </cite>
        </footer>
      </blockquote>
    </div>
  </div>
</div>