<?php

interface iBrake
{
  public function brake();
}