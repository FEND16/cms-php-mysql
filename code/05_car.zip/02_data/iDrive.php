<?php


interface iDrive
{
  public function drive();
}