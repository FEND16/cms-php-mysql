<?php

class Car extends Vehicle
{
  public function drive()
  {
    echo "I'm driving a car!";
    echo '<br/>';
    parent::drive();
  }

}