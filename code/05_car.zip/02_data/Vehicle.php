<?php



class Vehicle implements iDrive, iBrake
{
  public function brake()
  {
    echo '';
  }
  public function drive()
  {
    echo "I'm driving!";
  }
  public function goTo($destination)
  {
    echo "I'm going to " . $destination;
  }
}