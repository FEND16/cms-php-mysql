<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Object Oriented PHP</title>
  <style>
  body{
    margin: 100px 0 0 20px;
    font: 150%/1.5 'Fira Code', monospace;
  }
</style>
</head>
<body>
  <?php
    include 'iDrive.php';
    include 'iBrake.php';
    include 'Vehicle.php';
    include 'Car.php';

    $vehicle = new Vehicle;
    $car = new Car;
    $vehicle->drive();
    echo '<br/>';
    $car->drive();
    echo '<br/>';
    $car->goTo('Stockholm');

  ?>
</body>
</html>