<?php
foreach($data as $row){
    echo '<li>' . $row['model'] . '</li>';
}