<?php

class Products
{

  private $pdo;

  public function __construct($pdo)
  {
    $this->pdo = $pdo;
  }

  public function getAllFrom($product)
  {

    $statement = $this->pdo->prepare("
      SELECT * FROM $product");
    $statement->execute();
    return $statement->fetchAll();
  } 
}


