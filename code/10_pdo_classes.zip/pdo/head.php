<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PDO</title>
  <style>
  html{
    height: 100%;
  }
  body{
    height: 100%;
    background-color: #D7816A;
    color: #fff;
    font: 150%/1.5 'Fira Code', monospace;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items:center;
  }
</style>
</head>
<body>