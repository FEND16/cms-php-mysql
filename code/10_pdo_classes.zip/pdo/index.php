<?php
  include 'head.php';
  include 'database.php';
  include 'Products.php';
  include 'getTheStuff.php'
  include 'showTheStuff.php';
  include 'footer.php';