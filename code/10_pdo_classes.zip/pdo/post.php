<?php

include 'database.php';
include 'Products.php';

$products = new Products($pdo);

$products->login();