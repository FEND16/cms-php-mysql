<?php
$products = new Products($pdo);
$data = $products->getAllFrom('laptop');
$pcs = $products->getAllFrom('pc');