<form action="postPc.php" 
      method="POST" id="form">
  <div class="form-group">
    <input  type="text" 
            class="form-control" 
            name="model"
            placeholder="model">
  </div>
  <div class="form-group">
    <input  type="text" 
            class="form-control" 
            name="ram"
            placeholder="ram">
  </div>
  <div class="form-group">
    <input  type="text" 
            class="form-control" 
            name="price"
            placeholder="price">
  </div>
  <div class="form-group">
    <input  type="submit" 
            class="form-control btn btn-primary">
  </div>
</form>