<?php

include 'classes/Database.php';
include 'classes/Products.php';

$pdo = Database::connection();
$products = new Products($pdo);

$products->postPc();