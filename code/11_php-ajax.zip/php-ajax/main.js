let form = document.getElementById('form');


fetch('listAllPc.php')
  .then(data => data.json())
  .then(json => console.log(json));


form.addEventListener('submit', function(event){
  
  //Prevent form from submitting
  event.preventDefault();

  //Do post request to php
  fetch('postPc.php', {
    method: 'POST',
    body: new FormData(this) //format input-fields
  })
  .then(data => data.text())
  .then(text => console.log(text));

});





