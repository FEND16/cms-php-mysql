<?php include 'includes/head.php'; ?>

  <container class="p-5">
    <div class="row d-flex justify-content-center">
      <h1>Post! Post Post! 📬</h1>
    </div>
  </container>
  <div class="container p-5">
    <div class="row d-flex justify-content-center">
      <div class="col-xs-4">

        <?php include 'includes/form.php'; 
        ?>

      </div>
    </div>
  </div>

<?php include 'includes/footer.php'; ?>