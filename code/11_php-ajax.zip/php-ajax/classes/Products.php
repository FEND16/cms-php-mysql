<?php

class Products
{
  private $pdo;

  public function __construct($pdo)
  {
    $this->pdo = $pdo;
  }

  public function postPc()
  {
    $stmt = $this->pdo->prepare(
      "INSERT INTO pc
      (model, ram, price)
      VALUES
      (:model, :ram, :price)"
    );
    $stmt->execute([
      ":model"  => $_POST['model'],
      ":ram"    => $_POST['ram'],
      ":price"  => $_POST['price']
    ]);
  }
  public function listAll()
  {
    $stmt = $this->pdo->prepare(
      "SELECT * FROM pc");
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $data;
  }

  public function listAllJson($data)
  {
    echo json_encode($data);
  }
}




