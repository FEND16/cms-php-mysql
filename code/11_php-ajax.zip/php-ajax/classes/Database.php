<?php

class Database
{

  public static function connection()
  {
    return new PDO(
      'mysql:host=localhost:8889;dbname=Products;charset=utf8',
      'root', 
      'root');
  }
}