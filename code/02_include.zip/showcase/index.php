<!-- HEAD -->
<?php include 'partials/header.php'; ?>

<?php include 'partials/array.php'; ?>

<!-- BODY -->
<?php foreach($array as $name) : ?>
  <?php include 'partials/div.php'; ?>
<?php endforeach; ?>

<!-- HTML -->
<?php include 'partials/footer.php';?>









