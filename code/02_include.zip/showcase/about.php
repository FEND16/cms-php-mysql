<?php include 'header.php' ?>

  <div>
    <h1>About us!</h1>
  </div>

<?php include 'footer.php' ?>