<div>
  <ul>
    <li><?= $name ?></li>
  </ul>
</div>