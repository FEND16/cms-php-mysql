<?php 

$panda = array(
  "name" => "Panda",
  "weight" => "3000"
  );

echo $panda['name'];


if(true){
  echo "<h1>Hej!</h1>";
}else {
  echo "<h1> Inte hej! </h1>"; 
}

function blaj(){

  echo 'blajblaj!';
}
