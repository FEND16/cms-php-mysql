<?php 
  $array = array(
  "Jesper",
  "Steffe",
  "Luckas",
  "Balrog"
);